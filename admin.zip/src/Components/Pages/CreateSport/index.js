import Footer from "../../Footer";
import Navbar from "../../Navbar";

const CreateSport = () => {
    return (
        <>
            <Navbar />
            <div className="mx-3">
                <p className="fw-bold mt-3">Create Sport</p>
                <select className="form-control mt-3">

                </select>
            </div>
            <Footer />
        </>
    )
}

export default CreateSport;